class BesAsset < ApplicationRecord
end
