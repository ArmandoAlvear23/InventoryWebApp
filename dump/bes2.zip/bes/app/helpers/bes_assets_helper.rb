module BesAssetsHelper
end
