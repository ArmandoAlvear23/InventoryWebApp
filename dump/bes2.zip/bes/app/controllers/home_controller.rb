class HomeController < ApplicationController
  def home
  	@bes_assets = BesAsset.all
  end
end
