class MySessionsController < Devise::SessionsController

end
