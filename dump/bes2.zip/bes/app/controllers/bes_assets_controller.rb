class BesAssetsController < ApplicationController
  before_action :set_bes_asset, only: [:show, :edit, :update, :destroy]

  # GET /bes_assets
  # GET /bes_assets.json
  def index
    @bes_assets = BesAsset.all

  end

  # GET /bes_assets/1
  # GET /bes_assets/1.json
  def show
    add_rating()
    @bes_asset.save

  end

  # GET /bes_assets/new
  def new
    @bes_asset = BesAsset.new
  end

  # GET /bes_assets/1/edit
  def edit

  end

  # POST /bes_assets
  # POST /bes_assets.json
  def create
    @bes_asset = BesAsset.new(bes_asset_params)

    add_rating()

    respond_to do |format|
      if @bes_asset.save

        format.html { redirect_to @bes_asset, notice: 'BES Asset was successfully created.' }
        format.json { render :show, status: :created, location: @bes_asset }
      else
        format.html { render :new }
        format.json { render json: @bes_asset.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /bes_assets/1
  # PATCH/PUT /bes_assets/1.json
  def update

    fix_questions()

    respond_to do |format|
      if @bes_asset.update(bes_asset_params)
        format.html { redirect_to @bes_asset, notice: 'Bes asset was successfully updated.' }
        format.json { render :show, status: :ok, location: @bes_asset }
      else
        format.html { render :edit }
        format.json { render json: @bes_asset.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /bes_assets/1
  # DELETE /bes_assets/1.json
  def destroy
    @bes_asset.destroy
    respond_to do |format|
      format.html { redirect_to bes_assets_url, notice: 'Bes asset was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_bes_asset
      @bes_asset = BesAsset.find(params[:id])
    end

    def add_rating
      @bes_asset.high_impact = ""
      @bes_asset.medium_impact = ""
      @bes_asset.low_impact = ""


      if @bes_asset.asset_type == "CC"
        if @bes_asset.cc1 == "yes" or @bes_asset.cc2 == "yes" or @bes_asset.cc3 == "yes" or @bes_asset.cc4 == "yes"
          @bes_asset.high_impact = "TRUE"
          @bes_asset.medium_impact = ""
          @bes_asset.low_impact = ""
        elsif @bes_asset.cc5 == "yes" or @bes_asset.cc6 == "yes" or @bes_asset.cc7 == "yes"
          @bes_asset.medium_impact = "TRUE"
          @bes_asset.high_impact = ""
          @bes_asset.low_impact = ""
        elsif @bes_asset.cc8 == "yes"
          @bes_asset.low_impact = "TRUE"
          @bes_asset.high_impact = ""
          @bes_asset.medium_impact = ""
        end
      end

      if @bes_asset.asset_type == "TF"
        if @bes_asset.tf1 == "yes" or @bes_asset.tf2 == "yes" or @bes_asset.tf3 == "yes" or @bes_asset.tf4 == "yes" or @bes_asset.tf5 == "yes" or @bes_asset.tf6 == "yes"
          @bes_asset.medium_impact = "TRUE"
          @bes_asset.high_impact = ""
          @bes_asset.low_impact = ""
        elsif @bes_asset.tf7 == "yes" or @bes_asset.tf8 == "yes"
          @bes_asset.low_impact = "TRUE"
          @bes_asset.medium_impact = ""
          @bes_asset.high_impact = ""
        end
      end

      if @bes_asset.asset_type == "G"
        if @bes_asset.g1 == "yes" or @bes_asset.g2 == "yes" or @bes_asset.g3 == "yes"
          @bes_asset.medium_impact = "TRUE"
          @bes_asset.low_impact = ""
          @bes_asset.high_impact = ""
        elsif @bes_asset.g4 == "yes" or @bes_asset.g5 == "yes"
          @bes_asset.low_impact = "TRUE"
          @bes_asset.medium_impact = ""
          @bes_asset.high_impact = ""
        end
      end

      if @bes_asset.asset_type == "AA"
        if @bes_asset.aa1 == "yes" or @bes_asset.aa2 == "yes"
          @bes_asset.low_impact = ""
          @bes_asset.medium_impact = "TRUE"
          @bes_asset.high_impact = ""
        elsif @bes_asset.aa3 == "yes"
          @bes_asset.low_impact = "TRUE"
          @bes_asset.medium_impact = ""
          @bes_asset.high_impact = ""
        end
      end

      if @bes_asset.asset_type == "DP"
        if @bes_asset.dp1 == "yes"
          @bes_asset.low_impact = "TRUE"
          @bes_asset.medium_impact = ""
          @bes_asset.high_impact = ""
        end
      end


      # if @bes_asset.cc1 == "yes" or @bes_asset.cc2 == "yes" or @bes_asset.cc3 == "yes" or @bes_asset.cc4 == "yes"
      #   @bes_asset.high_impact = "TRUE"

      # elsif @bes_asset.cc5 == "yes" or @bes_asset.cc6 == "yes" or @bes_asset.cc7 == "yes" or @bes_asset.tf1 == "yes" or @bes_asset.tf2 == "yes" or @bes_asset.tf3 == "yes" or @bes_asset.tf4 == "yes" or @bes_asset.tf5 == "yes" or @bes_asset.tf6 == "yes" or @bes_asset.g1 == "yes" or @bes_asset.g2 == "yes" or @bes_asset.g3 == "yes" or @bes_asset.aa1 == "yes" or @bes_asset.aa2 == "yes"
      #   @bes_asset.medium_impact = 'TRUE'

      # elsif @bes_asset.cc8 == "yes" or @bes_asset.tf7 == "yes" or @bes_asset.tf8 == "yes" or @bes_asset.g4 == "yes" or @bes_asset.g5 == "yes" or @bes_asset.aa3 == "yes" or @bes_asset.dp1 == "yes"
      #   @bes_asset.low_impact = 'TRUE'

      # else
      #   @bes_asset.high_impact = @bes_asset.medium_impact = @bes_asset.low_impact = "PORQUE?!"

      # end

    end

    def fix_questions

    # @bes_asset.high_impact = @bes_asset.low_impact = @bes_asset.medium_impact = ""

    # if @bes_asset.high_impact == "TRUE"
    #   @bes_asset.high_impact = ""
    # end

    # if @bes_asset.medium_impact == "TRUE"
    #   @bes_asset.medium_impact = ""
    # end

    # if @bes_asset.low_impact == "TRUE"
    #   @bes_asset.low_impact = ""
    # end

    #add_rating()

    @bes_asset.cc1 = @bes_asset.cc2 = @bes_asset.cc3 = @bes_asset.cc4 = @bes_asset.cc5 = @bes_asset.cc6 = @bes_asset.cc7 = @bes_asset.cc8 = @bes_asset.tf1 = @bes_asset.tf2 = @bes_asset.tf3 = @bes_asset.tf4 = @bes_asset.tf5 = @bes_asset.tf6 = @bes_asset.tf7 = @bes_asset.tf8 = @bes_asset.g1 = @bes_asset.g2 = @bes_asset.g3 = @bes_asset.g4 = @bes_asset.g5 = @bes_asset.aa1 = @bes_asset.aa2 = @bes_asset.aa3 = @bes_asset.dp1 = ""

   #  if @bes_asset.asset_type == "CC"
   #    @bes_asset.tf1 = @bes_asset.tf2 = @bes_asset.tf3 = @bes_asset.tf4 = @bes_asset.tf5 = @bes_asset.tf6 = @bes_asset.tf7 = @bes_asset.tf8 = @bes_asset.g1 = @bes_asset.g2 = @bes_asset.g3 = @bes_asset.g4 = @bes_asset.g5 = @bes_asset.aa1 = @bes_asset.aa2 = @bes_asset.aa3 = @bes_asset.dp1 = ""

   #  elsif @bes_asset.asset_type == "TF"
   #    @bes_asset.cc1 = @bes_asset.cc2 = @bes_asset.cc3 = @bes_asset.cc4 = @bes_asset.cc5 = @bes_asset.cc6 = @bes_asset.cc7 = @bes_asset.cc8 = @bes_asset.g1 = @bes_asset.g2 = @bes_asset.g3 = @bes_asset.g4 = @bes_asset.g5 = @bes_asset.aa1 = @bes_asset.aa2 = @bes_asset.aa3 = @bes_asset.dp1 = ""

   #  elsif @bes_asset.asset_type = "G"
   #    @bes_asset.cc1 = @bes_asset.cc2 = @bes_asset.cc3 = @bes_asset.cc4 = @bes_asset.cc5 = @bes_asset.cc6 = @bes_asset.cc7 = @bes_asset.cc8 = @bes_asset.tf1 = @bes_asset.tf2 = @bes_asset.tf3 = @bes_asset.tf4 = @bes_asset.tf5 = @bes_asset.tf6 = @bes_asset.tf7 = @bes_asset.tf8 = @bes_asset.aa1 = @bes_asset.aa2 = @bes_asset.aa3 = @bes_asset.dp1 = ""

   #  elsif @bes_asset.asset_type = "AA"
   #   @bes_asset.cc1 = @bes_asset.cc2 = @bes_asset.cc3 = @bes_asset.cc4 = @bes_asset.cc5 = @bes_asset.cc6 = @bes_asset.cc7 = @bes_asset.cc8 = @bes_asset.tf1 = @bes_asset.tf2 = @bes_asset.tf3 = @bes_asset.tf4 = @bes_asset.tf5 = @bes_asset.tf6 = @bes_asset.tf7 = @bes_asset.tf8 = @bes_asset.g1 = @bes_asset.g2 = @bes_asset.g3 = @bes_asset.g4 = @bes_asset.g5 = @bes_asset.dp1 = ""

   # elsif @bes_asset.asset_type = "DP"
   #  @bes_asset.cc1 = @bes_asset.cc2 = @bes_asset.cc3 = @bes_asset.cc4 = @bes_asset.cc5 = @bes_asset.cc6 = @bes_asset.cc7 = @bes_asset.cc8 = @bes_asset.tf1 = @bes_asset.tf2 = @bes_asset.tf3 = @bes_asset.tf4 = @bes_asset.tf5 = @bes_asset.tf6 = @bes_asset.tf7 = @bes_asset.tf8 = @bes_asset.g1 = @bes_asset.g2 = @bes_asset.g3 = @bes_asset.g4 = @bes_asset.g5 = @bes_asset.aa1 = @bes_asset.aa2 = @bes_asset.aa3 = ""

  # end
end

    # Never trust parameters from the scary internet, only allow the white list through.
    def bes_asset_params
      params.require(:bes_asset).permit(:asset_id, :asset_type, :description, :commission, :decommission, :high_impact, :medium_impact, :low_impact, :erc, :dial_up, :region_op, :register_func, :cc1, :cc2, :cc3, :cc4, :cc5, :cc6, :cc7, :cc8, :tf1, :tf2, :tf3, :tf4, :tf5, :tf6, :tf7, :tf8, :g1, :g2, :g3, :g4, :g5, :aa1, :aa2, :aa3, :dp1)
    end
  end
