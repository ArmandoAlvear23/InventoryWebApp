require "application_system_test_case"

class BesAssetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit bes_assets_url
  #
  #   assert_selector "h1", text: "BesAsset"
  # end
end
