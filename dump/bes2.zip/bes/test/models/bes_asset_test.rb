require 'test_helper'

class BesAssetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
